/** @file
  GptWipe.c - UEFI Shell application to list block devices and zero the
  GPT protective structures (first 34 and last 34 sectors) of a
  user-selected disk.

  Build with EDK II:
    Place this directory under <edk2>/ShellPkg/Application/GptWipe/
    Add the .inf to ShellPkg/ShellPkg.dsc and ShellPkg/ShellPkg.fdf,
    then run:  build -p ShellPkg/ShellPkg.dsc -m ShellPkg/Application/GptWipe/GptWipe.inf

  Usage (UEFI Shell):
    GptWipe.efi

  WARNING: This tool PERMANENTLY DESTROYS partition table data.
           Use with extreme caution.
**/

#include <Uefi.h>
#include <Library/UefiLib.h>
#include <Library/UefiBootServicesTableLib.h>
#include <Library/UefiRuntimeServicesTableLib.h>
#include <Library/MemoryAllocationLib.h>
#include <Library/BaseMemoryLib.h>
#include <Library/DevicePathLib.h>
#include <Library/PrintLib.h>
#include <Protocol/BlockIo.h>
#include <Protocol/DiskInfo.h>
#include <Protocol/DevicePath.h>

// ---------------------------------------------------------------------------
// Constants
// ---------------------------------------------------------------------------

#define GPT_HEADER_SECTORS     34u   // LBA 0..33  (protective MBR + GPT header + entries)
#define SECTOR_SIZE_DEFAULT   512u   // fallback; real value read from BlockIo media

// ---------------------------------------------------------------------------
// Helper: read a single decimal character from the console
// Returns 0-based index or MAX_UINTN on ESC/invalid
// ---------------------------------------------------------------------------
static UINTN
ReadChoice (
  UINTN  MaxIndex   // inclusive upper bound (0-based)
  )
{
  EFI_STATUS   Status;
  EFI_INPUT_KEY Key;
  UINTN        Choice;

  for (;;) {
    // Flush stale input
    gST->ConIn->Reset (gST->ConIn, FALSE);

    // Wait for a key
    Status = gBS->WaitForEvent (1, &gST->ConIn->WaitForKey, &Choice);
    if (EFI_ERROR (Status)) {
      return MAX_UINTN;
    }

    Status = gST->ConIn->ReadKeyStroke (gST->ConIn, &Key);
    if (EFI_ERROR (Status)) {
      continue;
    }

    // ESC or 'q'/'Q' → cancel
    if (Key.ScanCode == SCAN_ESC ||
        Key.UnicodeChar == L'q'  ||
        Key.UnicodeChar == L'Q') {
      return MAX_UINTN;
    }

    // Digit?
    if (Key.UnicodeChar >= L'0' && Key.UnicodeChar <= L'9') {
      Choice = (UINTN)(Key.UnicodeChar - L'0');
      if (Choice <= MaxIndex) {
        Print (L"%c\n", Key.UnicodeChar);
        return Choice;
      }
    }

    // Allow multi-digit entry (up to 2 digits) for >9 disks
    if (Key.UnicodeChar >= L'1' && Key.UnicodeChar <= L'9') {
      UINTN First = (UINTN)(Key.UnicodeChar - L'0');
      Print (L"%c", Key.UnicodeChar);

      // Try to read a second digit with a short wait
      EFI_EVENT  TimerEvent;
      Status = gBS->CreateEvent (EVT_TIMER, TPL_CALLBACK, NULL, NULL, &TimerEvent);
      if (!EFI_ERROR (Status)) {
        gBS->SetTimer (TimerEvent, TimerRelative, 15000000ULL); // 1.5 s
        UINTN       WaitIdx;
        EFI_EVENT   WaitList[2] = { gST->ConIn->WaitForKey, TimerEvent };
        Status = gBS->WaitForEvent (2, WaitList, &WaitIdx);
        gBS->CloseEvent (TimerEvent);

        if (!EFI_ERROR (Status) && WaitIdx == 0) {
          EFI_INPUT_KEY Key2;
          if (!EFI_ERROR (gST->ConIn->ReadKeyStroke (gST->ConIn, &Key2)) &&
              Key2.UnicodeChar >= L'0' && Key2.UnicodeChar <= L'9') {
            UINTN TwoDigit = First * 10 + (UINTN)(Key2.UnicodeChar - L'0');
            Print (L"%c\n", Key2.UnicodeChar);
            if (TwoDigit <= MaxIndex) {
              return TwoDigit;
            }
            Print (L"  [Invalid choice - try again]\n");
            continue;
          }
        }
      }

      // Single digit commit
      Print (L"\n");
      if (First <= MaxIndex) {
        return First;
      }
    }

    Print (L"  [Invalid choice - try again]\n");
  }
}

// ---------------------------------------------------------------------------
// Helper: get a short human-readable description from device path
// Caller must FreePool() the returned string.
// ---------------------------------------------------------------------------
static CHAR16 *
ShortDevPathStr (
  EFI_DEVICE_PATH_PROTOCOL  *DevPath
  )
{
  CHAR16  *Full;
  CHAR16  *Short;
  UINTN    Len;

  if (DevPath == NULL) {
    Short = AllocateCopyPool (sizeof (L"(unknown)"), L"(unknown)");
    return Short;
  }

  Full = ConvertDevicePathToText (DevPath, FALSE, FALSE);
  if (Full == NULL) {
    Short = AllocateCopyPool (sizeof (L"(unknown)"), L"(unknown)");
    return Short;
  }

  // Truncate to 72 chars for display
  Len = StrLen (Full);
  if (Len > 72) {
    Full[69] = L'.';
    Full[70] = L'.';
    Full[71] = L'.';
    Full[72] = L'\0';
  }

  return Full;  // caller frees
}

// ---------------------------------------------------------------------------
// Helper: build a short bus-type tag from device path nodes
// e.g. "NVMe", "SATA", "USB", "MMC", "SCSI", "VirtIO", "Unknown"
// ---------------------------------------------------------------------------
static CONST CHAR16 *
GuessBusType (
  EFI_DEVICE_PATH_PROTOCOL  *DevPath
  )
{
  EFI_DEVICE_PATH_PROTOCOL *Node;

  if (DevPath == NULL) {
    return L"Unknown";
  }

  for (Node = DevPath;
       !IsDevicePathEndType (Node);
       Node = NextDevicePathNode (Node)) {

    UINT8 Type    = DevicePathType (Node);
    UINT8 SubType = DevicePathSubType (Node);

    if (Type == MESSAGING_DEVICE_PATH) {
      switch (SubType) {
        case MSG_NVME_NAMESPACE_DP:  return L"NVMe";
        case MSG_SATA_DP:            return L"SATA";
        case MSG_USB_DP:             return L"USB";
        case MSG_USB_CLASS_DP:       return L"USB";
        case MSG_SCSI_DP:            return L"SCSI";
        case MSG_ATAPI_DP:           return L"ATAPI";
        case MSG_SD_DP:              return L"SD";
        case MSG_EMMC_DP:            return L"eMMC";
        case MSG_UFS_DP:             return L"UFS";
        case MSG_VLAN_DP:            return L"Net";  // unlikely for block dev
        default:                     break;
      }
    }

    // VirtIO / paravirt (Type=Hardware, SubType=Vendor with known GUID) --
    // just note it as VirtIO loosely if we spot a vendor hardware node
    if (Type == HARDWARE_DEVICE_PATH && SubType == HW_VENDOR_DP) {
      return L"Vendor/VirtIO";
    }
  }

  return L"Unknown";
}

// ---------------------------------------------------------------------------
// Zero a contiguous range of sectors on a BlockIo device.
// Uses a 1 MiB stack-on-heap buffer to keep allocations reasonable.
// ---------------------------------------------------------------------------
#define WIPE_BUF_SECTORS  2048u   // 2048 * 512 = 1 MiB

static EFI_STATUS
ZeroSectors (
  EFI_BLOCK_IO_PROTOCOL  *BlockIo,
  UINT64                  StartLba,
  UINT64                  SectorCount
  )
{
  EFI_STATUS  Status;
  UINT32      BlockSize   = BlockIo->Media->BlockSize;
  UINT64      Remaining   = SectorCount;
  UINT64      CurrentLba  = StartLba;
  UINTN       BufSectors  = WIPE_BUF_SECTORS;
  UINTN       BufBytes    = BufSectors * BlockSize;
  UINT8      *ZeroBuf;

  // Clamp buffer to actual block size multiple
  if (BufBytes < BlockSize) {
    BufBytes   = BlockSize;
    BufSectors = 1;
  }

  ZeroBuf = AllocateZeroPool (BufBytes);
  if (ZeroBuf == NULL) {
    return EFI_OUT_OF_RESOURCES;
  }

  while (Remaining > 0) {
    UINT64 ThisSectors = (Remaining < BufSectors) ? Remaining : BufSectors;
    UINTN  ThisBytes   = (UINTN)(ThisSectors * BlockSize);

    Status = BlockIo->WriteBlocks (
               BlockIo,
               BlockIo->Media->MediaId,
               CurrentLba,
               ThisBytes,
               ZeroBuf
               );
    if (EFI_ERROR (Status)) {
      FreePool (ZeroBuf);
      return Status;
    }

    CurrentLba += ThisSectors;
    Remaining  -= ThisSectors;
  }

  Status = BlockIo->FlushBlocks (BlockIo);
  FreePool (ZeroBuf);
  return Status;
}

// ---------------------------------------------------------------------------
// Entry point
// ---------------------------------------------------------------------------
EFI_STATUS
EFIAPI
UefiMain (
  IN EFI_HANDLE        ImageHandle,
  IN EFI_SYSTEM_TABLE  *SystemTable
  )
{
  EFI_STATUS               Status;
  UINTN                    HandleCount   = 0;
  EFI_HANDLE              *HandleBuffer  = NULL;
  UINTN                    DiskCount     = 0;
  UINTN                    Idx;

  // Arrays to track candidate disks (max 64)
#define MAX_DISKS 64
  EFI_BLOCK_IO_PROTOCOL   *DiskBlockIo[MAX_DISKS];
  CHAR16                  *DiskPath[MAX_DISKS];
  CONST CHAR16            *DiskBus[MAX_DISKS];

  Print (L"\n");
  Print (L"=========================================\n");
  Print (L"  GptWipe - GPT Partition Table Eraser  \n");
  Print (L"=========================================\n");
  Print (L"  WARNING: This tool PERMANENTLY erases  \n");
  Print (L"  GPT data. Proceed with caution!        \n");
  Print (L"=========================================\n\n");

  // ---------------------------------------------------------
  // Locate all handles that expose BlockIo
  // ---------------------------------------------------------
  Status = gBS->LocateHandleBuffer (
                  ByProtocol,
                  &gEfiBlockIoProtocolGuid,
                  NULL,
                  &HandleCount,
                  &HandleBuffer
                  );
  if (EFI_ERROR (Status) || HandleCount == 0) {
    Print (L"No block devices found (Status=%r).\n", Status);
    return EFI_NOT_FOUND;
  }

  // ---------------------------------------------------------
  // Filter: keep only whole disks (not partitions)
  //   BlockIo->Media->LogicalPartition == FALSE
  //   BlockIo->Media->LastBlock        >  0
  // ---------------------------------------------------------
  for (Idx = 0; Idx < HandleCount && DiskCount < MAX_DISKS; Idx++) {
    EFI_BLOCK_IO_PROTOCOL        *Bio  = NULL;
    EFI_DEVICE_PATH_PROTOCOL     *Dp   = NULL;

    Status = gBS->HandleProtocol (
                    HandleBuffer[Idx],
                    &gEfiBlockIoProtocolGuid,
                    (VOID **)&Bio
                    );
    if (EFI_ERROR (Status) || Bio == NULL) {
      continue;
    }

    // Skip partition child handles and zero-size media
    if (Bio->Media->LogicalPartition || Bio->Media->LastBlock == 0) {
      continue;
    }

    // Skip removable media that has no media present
    if (!Bio->Media->MediaPresent) {
      continue;
    }

    Status = gBS->HandleProtocol (
                    HandleBuffer[Idx],
                    &gEfiDevicePathProtocolGuid,
                    (VOID **)&Dp
                    );
    // Device path is optional — proceed even if absent

    DiskBlockIo[DiskCount] = Bio;
    DiskPath[DiskCount]    = ShortDevPathStr (Dp);
    DiskBus[DiskCount]     = GuessBusType (Dp);
    DiskCount++;
  }

  FreePool (HandleBuffer);

  if (DiskCount == 0) {
    Print (L"No whole-disk block devices found.\n");
    return EFI_NOT_FOUND;
  }

  // ---------------------------------------------------------
  // Display disk list
  // ---------------------------------------------------------
  Print (L"Detected disks:\n\n");
  Print (L"  %-4s %-8s %-12s  %s\n", L"#", L"Bus", L"Size", L"Device Path");
  Print (L"  %-4s %-8s %-12s  %s\n", L"---", L"-------", L"-----------", L"-------------------------------------------");

  for (Idx = 0; Idx < DiskCount; Idx++) {
    EFI_BLOCK_IO_MEDIA *Media = DiskBlockIo[Idx]->Media;
    UINT64 SizeBytes = (Media->LastBlock + 1) * Media->BlockSize;
    UINT64 SizeGiB   = SizeBytes / (1024ULL * 1024ULL * 1024ULL);
    UINT64 SizeMiB   = (SizeBytes % (1024ULL * 1024ULL * 1024ULL)) / (1024ULL * 1024ULL);

    CHAR16 SizeBuf[24];
    if (SizeGiB > 0) {
      UnicodeSPrint (SizeBuf, sizeof (SizeBuf), L"%Lu.%02Lu GiB", SizeGiB,
                     (SizeMiB * 100) / 1024);
    } else {
      UnicodeSPrint (SizeBuf, sizeof (SizeBuf), L"%Lu MiB", SizeMiB);
    }

    Print (L"  [%Lu] %-8s %-12s  %s\n",
           (UINT64)Idx,
           DiskBus[Idx],
           SizeBuf,
           DiskPath[Idx]);
  }

  Print (L"\n");

  // ---------------------------------------------------------
  // User selection
  // ---------------------------------------------------------
  Print (L"Enter disk number to wipe GPT (ESC or Q to cancel): ");
  UINTN Choice = ReadChoice (DiskCount - 1);

  if (Choice == MAX_UINTN) {
    Print (L"\nCancelled. No changes made.\n");
    goto Cleanup;
  }

  // ---------------------------------------------------------
  // Confirmation prompt
  // ---------------------------------------------------------
  {
    EFI_BLOCK_IO_MEDIA *Media   = DiskBlockIo[Choice]->Media;
    UINT64              TotalLba = Media->LastBlock + 1;

    Print (L"\nSelected disk [%Lu]: %s\n", (UINT64)Choice, DiskPath[Choice]);
    Print (L"  BlockSize : %u bytes\n", Media->BlockSize);
    Print (L"  Sectors   : %Lu\n", (UINT64)(Media->LastBlock + 1));

    if (TotalLba < GPT_HEADER_SECTORS * 2) {
      Print (L"\nERROR: Disk is too small to contain a GPT (%Lu sectors).\n",
             (UINT64)TotalLba);
      goto Cleanup;
    }

/*
    Print (L"\n  Will zero LBA 0..%u  (first %u sectors)\n",
           GPT_HEADER_SECTORS - 1, GPT_HEADER_SECTORS);
    Print (L"  Will zero LBA %Lu..%Lu  (last %u sectors)\n",
           (UINT64)(TotalLba - GPT_HEADER_SECTORS),
           (UINT64)(TotalLba - 1),
           GPT_HEADER_SECTORS);
    Print (L"\n");
    Print (L"  *** ALL GPT DATA ON THIS DISK WILL BE PERMANENTLY LOST ***\n\n");
    Print (L"Type YES (uppercase) and press Enter to confirm, or anything else to abort:\n> ");

    // Read a short string for "YES"
    CHAR16  Confirm[16];
    UINTN   ConfirmLen = 0;
    ZeroMem (Confirm, sizeof (Confirm));

    gST->ConIn->Reset (gST->ConIn, FALSE);
    for (;;) {
      UINTN         WaitIdx;
      EFI_INPUT_KEY K;
      gBS->WaitForEvent (1, &gST->ConIn->WaitForKey, &WaitIdx);
      if (EFI_ERROR (gST->ConIn->ReadKeyStroke (gST->ConIn, &K))) {
        continue;
      }
      if (K.UnicodeChar == L'\r' || K.UnicodeChar == L'\n') {
        Print (L"\n");
        break;
      }
      if (K.UnicodeChar == CHAR_BACKSPACE) {
        if (ConfirmLen > 0) {
          ConfirmLen--;
          Confirm[ConfirmLen] = L'\0';
          Print (L"\b \b");
        }
        continue;
      }
      if (K.ScanCode == SCAN_ESC) {
        ConfirmLen = 0;
        Print (L"\n");
        break;
      }
      if (ConfirmLen < 7) {
        Confirm[ConfirmLen++] = K.UnicodeChar;
        Print (L"%c", K.UnicodeChar);
      }
    }

    if (StrCmp (Confirm, L"YES") != 0) {
      Print (L"Aborted. No changes made.\n");
      goto Cleanup;
    }
*/
    // ---------------------------------------------------------
    // Wipe front GPT (LBA 0 .. GPT_HEADER_SECTORS-1)
    // ---------------------------------------------------------
    Print (L"\nZeroing first %u sectors (LBA 0..%u)...\n",
           GPT_HEADER_SECTORS, GPT_HEADER_SECTORS - 1);

    Status = ZeroSectors (DiskBlockIo[Choice], 0, GPT_HEADER_SECTORS);
    if (EFI_ERROR (Status)) {
      Print (L"ERROR writing first sectors: %r\n", Status);
      goto Cleanup;
    }

    // ---------------------------------------------------------
    // Wipe back GPT (last GPT_HEADER_SECTORS sectors)
    // ---------------------------------------------------------
    UINT64 BackStart = TotalLba - GPT_HEADER_SECTORS;

    Print (L"Zeroing last %u sectors  (LBA %Lu..%Lu)...\n",
           GPT_HEADER_SECTORS,
           (UINT64)BackStart,
           (UINT64)(TotalLba - 1));

    Status = ZeroSectors (DiskBlockIo[Choice], BackStart, GPT_HEADER_SECTORS);
    if (EFI_ERROR (Status)) {
      Print (L"ERROR writing last sectors: %r\n", Status);
      goto Cleanup;
    }

    Print (L"\nDone. GPT structures have been zeroed on disk [%Lu].\n",
           (UINT64)Choice);
    Print (L"You may need to reboot for firmware changes to take effect.\n\n");
  }

Cleanup:
  for (Idx = 0; Idx < DiskCount; Idx++) {
    if (DiskPath[Idx] != NULL) {
      FreePool (DiskPath[Idx]);
    }
  }
  return EFI_SUCCESS;
}
