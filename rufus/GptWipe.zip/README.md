# GptWipe — UEFI GPT Eraser

A UEFI Shell application that enumerates all whole-disk block devices on the
system, lets the user pick one interactively, and zeroes **both** GPT
structures (first 34 sectors and last 34 sectors).

---

## Quickbuild

```
cp -r GptWipe <edk2>/ShellPkg/Application/
# Add the .inf to ShellPkg.dsc Components section, then:
build -p ShellPkg/ShellPkg.dsc \
      -m ShellPkg/Application/GptWipe/GptWipe.inf \
      -a X64 -t GCC5
```

## What it does

| Region zeroed | LBAs | Contents destroyed |
|---|---|---|
| Front GPT | LBA 0 – 33 | Protective MBR (LBA 0), Primary GPT Header (LBA 1), Primary GPT Entries (LBA 2–33) |
| Back GPT  | LBA (N-34) – (N-1) | Backup GPT Entries, Backup GPT Header |

After wiping, the disk appears as unpartitioned / raw to any OS or firmware
that scans for a GPT. An MBR-style partition table (if present) is also
destroyed because LBA 0 is zeroed.

---

## Building

### Prerequisites

* EDK II source tree (github.com/tianocore/edk2), fully set up
* A working compiler toolchain: GCC (Linux/macOS) or Visual Studio (Windows)

### Steps

```bash
# 1. Copy the application into EDK II
cp -r GptWipe  <edk2>/ShellPkg/Application/

# 2. Register it in ShellPkg.dsc  (Components section)
#    Add this line:
#      ShellPkg/Application/GptWipe/GptWipe.inf

# 3. Optionally add to ShellPkg.fdf if building a firmware image
#    (not needed for a standalone .efi)

# 4. Build
cd <edk2>
source edksetup.sh          # Linux / macOS
# or edksetup.bat BaseTools  # Windows

build -p ShellPkg/ShellPkg.dsc \
      -m ShellPkg/Application/GptWipe/GptWipe.inf \
      -a X64 \
      -t GCC5          # or VS2022, CLANGDWARF, etc.
```

The resulting binary is at:
```
<edk2>/Build/Shell/DEBUG_GCC5/X64/GptWipe.efi
```
(path varies with arch and toolchain).

### Cross-compile for ARM64

```bash
build -p ShellPkg/ShellPkg.dsc \
      -m ShellPkg/Application/GptWipe/GptWipe.inf \
      -a AARCH64 \
      -t GCC5
```

---

## Usage

1. Copy `GptWipe.efi` to a FAT32 USB stick or the EFI System Partition.
2. Boot to UEFI Shell (usually by pressing F2/Del/Esc at POST and choosing
   "UEFI Shell", or by naming it `BOOTX64.EFI` on a USB stick).
3. Run:
   ```
   FS0:\> GptWipe.efi
   ```
4. A numbered list of detected whole disks is shown, e.g.:
   ```
   #    Bus      Size          Device Path
   ---  -------  -----------   -------------------------------------------
   [0]  NVMe     512.00 GiB    PciRoot(0)/Pci(0x1,0x0)/NVMe(...)
   [1]  SATA     1000.20 GiB   PciRoot(0)/Pci(0x17,0x0)/Sata(...)
   [2]  USB      14.91 GiB     PciRoot(0)/Pci(0x14,0x0)/USB(...)
   ```
5. Type the number of the disk to wipe and press Enter.
6. Confirm by typing **YES** (uppercase) and pressing Enter.
7. The tool writes zeroes to the first 34 and last 34 sectors, flushes, and
   reports success.

Press **ESC** or **Q** at any prompt to cancel with no changes made.

---

## Safety design

* Partition child handles (`LogicalPartition == TRUE`) are excluded; only
  whole-disk handles are listed.
* A double confirmation is required (disk number + typing "YES").
* Any I/O error during zeroing is reported immediately and the remaining
  regions are skipped.
* The tool never touches any sector outside the two 34-sector GPT regions.

---

## Limitations / Notes

* **UEFI write-protect**: Some firmware implementations mark the boot device
  read-only. In that case `WriteBlocks` returns `EFI_WRITE_PROTECTED`.
* **Sector size**: The tool respects whatever `BlockSize` the firmware reports
  (512 or 4096 bytes). "34 sectors" means 34 × BlockSize bytes in each region.
* **NVMe namespaces**: Each NVMe namespace appears as a separate block device.
  Select the correct namespace (usually NS 1 is the whole drive).
* **Reboot recommended** after wiping so the firmware re-scans partition tables.
